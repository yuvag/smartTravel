<?php
	function process($data){
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);	
		return $data;
	}
	function checkdata($data){
		//This function will check whether data does not contain any invalid literal
		$pattern = "/^[a-zA-Z0-9_]*$/";
		if(preg_match($pattern,$data))
			return true;
		else
			return false;
	}

	function check_stopName($data){
		$pattern = "/^[a-zA-Z0-9_ ]*$/";
		if(preg_match($pattern,$data))
			return true;
		else 
			return false;	
	}
?>
