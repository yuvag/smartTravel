<?php
	$code_file = getcwd().DIRECTORY_SEPARATOR."codeFiles".DIRECTORY_SEPARATOR."codeFile";
	
	class codeNode{
		var $isFree;
		var $child;
		function __construct(){
			$this->isFree = array();
			$this->child = array();		
		}	
	}

	$codeTree = NULL;
	$digits = 4;	
	$code_loaded = false;
	$code_saved = true;
	$code = "";
	
	function load_code_file(){
		global $code_file,$codeTree,$digits,$code_saved;
		if(!file_exists($code_file)){
			$codeTree = new codeNode();
			initialise_tree($codeTree,$digits);
			$code_saved = false;		
		}
		else{
			$objdata = file_get_contents($code_file);
			$codeTree = unserialize($objdata);		
		}	
	}

	function initialise_tree($root,$level){
		if($level == 0)
			return;
		for($i = 0;$i < 10;$i++){
			$root->isFree[$i] = true;
			$root->child[$i] = new codeNode();
			initialise_tree($root->child[$i],$level - 1);
		}			
	}
	
	function save_code_file(){
		global $codeTree,$code_file;
		$objdata = serialize($codeTree);
		$fp = fopen($code_file,"w");
		fwrite($fp,$objdata);
		fclose($fp);
	}
		
	function finish_my_code_work(){
		global $code_saved,$code_loaded;
		if(!$code_saved){
			$code_loaded = false;
			save_code_file();
			$code_saved = true;		
		}			
	}

	function generate_code(){
		global $code_loaded,$code_saved,$codeTree,$digits,$code;
		$code = "";
		if(!$code_loaded){
			$code_loaded = true;
			load_code_file();		
		}
		if(find_code($codeTree,$digits)){
			$code_saved = false;
			return $code;
		}
		else
			return -1;
	}
	
	function find_code($root,$level){
		global $code;
		if($level == 0)
			return false;
		for($i = 0;$i < 10;$i++){
			if($root->isFree[$i]){
				$code = $code.$i;
				find_code($root->child[$i],$level-1);
				$found = false;
				for($j=0;$j < 10;$j++)
					if(isset($root->child[$i]->isFree[$j]) and ($root->child[$i]->isFree[$j]))
						$found = true;
				if(!$found)
					$root->isFree[$i] = false;	
				break;			
			}		
		} 
		return true;			
	}
	
	function destroy_code($code){
		global $code_loaded,$code_saved,$codeTree;
		if(!$code_loaded){
			$code_loaded = true;
			load_code_file();		
		}			
		free_code($codeTree,$code);
		$_code_saved = false;
	}
	
	function free_code($root,$code){
		for($i = 0;$i < strlen($code);$i++){
			$root->isFree[intval($code[$i])] = true;
			$root = $root->child[intval($code[$i])];		
		}					
	}		
	
?>
