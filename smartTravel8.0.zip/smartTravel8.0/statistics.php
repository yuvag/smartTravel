<?php 
	session_start();
?>

<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php 
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
			
			if($_SESSION['privilege'] != 1){		
				header('HTTP/1.0 404 Not Found');
				die("<h1>404 Not Found</h1>");
			}
		?>
		<br>
		<a href = "adminPage.php">Home</a>
		<br>
		<?php
			require('dbmanager.php');
			$users = no_of_users();
			$ticketingDevice = no_of_ticketing_device();
			echo "<p> Total Users : $users</p>";
			echo "<p> Total ticketing Device : $ticketingDevice </p>";		
		?>
	</body>
</html>
