<?php
	session_start();
	require('fileProcessor.php');
	$src_error = "";
	$dest_error = "";
	$eta_error = "";	
	$etd_error = "";
	$day_error = "";	
	$error = "";
	$fare_error = "";
	$etaOK = false;
	$srcOK = false;
	$destOK = false;
	$fareOK = false;	
	$etdOK = false;
	$dayOK = false;
	$src = "";
	$dest="";
	$fare = 0;
	$vehicle = "";
	$day = "";
	$eta = "";
	$etd = "";
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		$vehicleType = $_POST['vehicleType'];
		if($vehicleType == "metro"){
		
			if(!empty($_POST['from']) and is_a_valid_metro_station($_POST['from'])){
				$src = $_POST['from'];
				$srcOK = true;
			}
			else
				$src_error = "Source name is not valid";
			finish_my_work();
			if(!empty($_POST['to']) and is_a_valid_metro_station($_POST['to'])){
				$dest = $_POST['to'];
				$destOK = true;
			}
			else
				$dest_error = "Destination name is not valid";
			finish_my_work();
			if(strtotime($_POST['eta'])){
				$eta = date_create($_POST['eta']);
				$etaOK = true;
			}
			else
				$eta_error = "STime is not valid.Format should be HH:MM:SS (in 24-hours).";
			if(strtotime($_POST['etd'])){
				$etd = date_create($_POST['etd']);
				if($etd > $eta)
					$etdOK = true;
				else
					$etd_error = "DTime must be greater than STime";
			}
			else
				$etd_error = "DTime is not valid.Format should be HH:MM:SS (in 24-hours).";
			
			if(isset($_POST['day'])){
				$day =$_POST['day'];
				$dayOK = true;
			}
			else
				$day_error = "Atleast a day should be selected";
			if($srcOK and $destOK and $etaOK and $etdOK  and $dayOK){
				foreach($day as $d)
					add_metro_route($src,$eta,$dest,$etd,$d);
				display_metro();		
				finish_my_work();
				$error = "Route created successfully!";			
			}
		}
		else if($vehicleType == "bus"){
			if(is_a_valid_bus_stop($_POST['from'])){
				$src = $_POST['from'];
				$srcOK = true;
			}
			else
				$src_error = "Source name is not valid";
			finish_my_work();
			if(is_a_valid_bus_stop($_POST['to'])){
				$dest = $_POST['to'];
				$destOK = true;
			}
			else
				$dest_error = "Destination name is not valid";
			finish_my_work();
			if(strtotime($_POST['eta'])){
				$eta = date_create($_POST['eta']);
				$etaOK = true;
			}
			else
				$eta_error = "ETA is not valid.Format should be HH:MM:SS (in 24-hours).";
			if(strtotime($_POST['etd'])){
				$etd = date_create($_POST['etd']);
				$etdOK = true;
			}
			else
				$etd_error = "ETD is not valid.Format should be HH:MM:SS (in 24-hours).";
			$vehicle = $_POST['vehicle'];
			if(is_numeric($_POST['fare'])){
				$fare = intval($_POST['fare']);
				$fareOK = true;
			}
			else
				$fare_error = "Fare should contain only digits";
			if(isset($_POST['day'])){
				$day = $_POST['day'];
				$dayOK = true;
			}
			else
				$day_error = "Atleast a day should be selected";
			if($srcOK and $destOK and $etaOK and $etdOK and $fareOK and $dayOK){
				foreach($day as $d)
					add_bus_route($src,$eta,$dest,$etd,$vehicle,$fare,$d);
				
				display_bus();
				finish_my_work();
				$error = "Route created successfully!";			
			}
			
		}	
	}
?>
<!doctype html>
<html>
	<head>
		<title>SmartTravel</title>
		 <link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.1/themes/base/minified/jquery-ui.min.css" type="text/css" />

	</head>
	<body>
		<?php
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
			if($_SESSION['privilege'] != 1){
				header("HTTP/1.1 404 Not Found");	
				die("<h1>404 Not Found</h1>");			
			}
		?>
		<a href = "adminPage.php">Home</a>
		<form action = "<?php echo $_SERVER['PHP_SELF'] ?>" method = "POST">
			<input type="radio" name="vehicleType" value="metro" onclick="document.getElementById('vehicle').style.display='none';document.getElementById('fare').style.display='none';">Metro</input>
			<input type="radio" name="vehicleType" value="bus" onclick="document.getElementById('fare').style.display='block'; document.getElementById('vehicle').style.display='block';" checked>Bus</input>
			<p id="tmp"></p>
			<br>
			<input type="text" placeholder="From" name="from" class = "auto">
			<a href = "newStopAddition.php">Add</a>
			<?php echo "<p>$src_error</p>"; ?> 
			<br>
			<input type="text" placeholder="To" name ="to" class = "auto">	
			<a href = "newStopAddition.php">Add</a>
			<?php echo "<p>$dest_error</p>"; ?>
			<br>			
			<input type="time" placeholder="STime(HH:MM:SS) (24-Hours)" name = "eta" >
			<?php echo "<p>$eta_error</p>"; ?>
			<br>
			<input type="time" placeholder="DTime(HH:MM:SS) (24-Hours)" name ="etd" >
			<?php echo "<p>$etd_error</p>"; ?>
			<br>
		
			<input type="text" id= "vehicle" placeholder="Vehicle" name = "vehicle" >
			<br>
		
			<input type="text" id= "fare" placeholder="Fare" name="fare">
			<?php echo "<p>$fare_error</p>";?>
			<br>			
			<input type="checkbox" name="day[]" value=0>Sunday</input>
			<input type="checkbox" name="day[]" value=1>Monday</input>
			<input type="checkbox" name="day[]" value=2>Tuesday</input>
			<input type="checkbox" name="day[]" value=3>Wednesday</input>
			<input type="checkbox" name="day[]" value=4>Thursday</input>
			<input type="checkbox" name="day[]" value=5>Friday</input>
			<input type="checkbox" name="day[]" value=6>Saturday</input>
			<?php echo "<p>$day_error</p>"; ?>
			<?php echo "<p>$error</p>"; ?>
			<input type="submit" value = "Add"/>
		</form>
		
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>	
		<script type="text/javascript">
		$(function() {
	
			//autocomplete
			$(".auto").autocomplete({
				source: function(request,response){
					$.getJSON("search.php",{term:request.term,vehicleType:$('input[name=vehicleType]:checked').val()},response);
			
				},
				minLength: 2
			});				

		});	
		</script>	
	</body>
</html>
