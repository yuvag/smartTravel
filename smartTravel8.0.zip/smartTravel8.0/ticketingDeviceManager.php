<?php 
	session_start();
?>

<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php 
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
			
			if($_SESSION['privilege'] != 1){
				header('HTTP/1.0 404 Not Found');
				die("<h1>404 Not Found</h1>");
			}
		?>
		<a href = "adminPage.php">Home</a>
		<br>
		<a href = "ticketingDeviceActivate.php">Activate a ticketing device</a>
		<br>
		<a href = "ticketingDeviceDeactivate.php">Deactivate a ticketing device</a>
		<br>
		<a href = "ticketingDeviceAccount.php">Manage account</a>
		<br>
	</body>
</html>
