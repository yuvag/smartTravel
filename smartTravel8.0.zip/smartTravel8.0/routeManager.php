<?php 
	session_start();
?>

<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php 
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
			
			if($_SESSION['privilege'] != 1){
				header('HTTP/1.0 404 Not Found');
				die("<h1>404 Not Found</h1>");
			}
		?>
		<a href = "adminPage.php">Home</a>
		<br>
		<a href = "routeadder.php">Add a route</a>
		<br>
		
		<a href = "newStopAddition.php">Add a stop</a>
		<br> 	

		<a href = "routeDeletion.php">Delete route</a>
		<br>
		
		<a href = "logout.php"> Logout</a>
		<br>
	</body>
</html>
