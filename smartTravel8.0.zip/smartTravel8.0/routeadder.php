<?php
	session_start();
?>
<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php
			if(empty($_SESSION['username'])){
				header('HTTP/1.1 404 Not Found');
				die("<h1>404 Not Found</h1>");			
			}
			if($_SESSION['privilege'] != 1){
				header('HTTP/1.1 404 Not Found');	
				die("<h1>404 Not Found<h1>");			
			}
		?>
		<a href = "adminPage.php">Home </a><br>
		<a href = "manualrouteaddition.php"> Add route manually</a><br>
		<a href = "routefileaddition.php"> Upload a route file</a>
	
	</body>
</html>
