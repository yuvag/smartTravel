<?php
	session_start();
	require('dbmanager.php');
	require('check.php');
	$usernameOK = false;
	$error = "";
	if($_SERVER['REQUEST_METHOD'] == "POST"){
		if(empty($_POST['username']))
			$error = "Username can't be empty";
		else{
			$username = process($_POST['username']);
			if(checkdata($username))
				$usernameOK = true;			
			else
				$error = "Username can't contain illegal characters";
		}
		if($usernameOK){
			if(is_a_valid_user($username)){	
				$privilege = privilege_level($username);
				if($privilege == 1)
					$error = "Admin cannot be ticketing device";
				else if($privilege == 2)
					$error = "Already a ticketing device";
				else if($privilege == 3)
					if(promote($username,2,$_POST['fareType'],$_POST['vehicleType']))
						$error = "Ticketing device activated!";
					else
						$error = "There is some error.Try contacting administrator";
				else
					$error = "There is some error.Try contacting administrator"; 			
			}	
			else
				$error = "User doesn't exist";	
		}		
	}
?>

<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		
		<?php 
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
			
			if($_SESSION['privilege'] != 1){
				header('HTTP/1.0 404 Not Found');
				die("<h1>404 Not Found</h1>");
			}
		?>
		<a href = "adminPage.php">Home</a>
		<form action = "<?php echo $_SERVER['PHP_SELF'] ?>" method = "POST">
			Username : <input type = "text" name = "username"/>
			<br>
			Fare : <input type = "radio" name = "fareType" value=1 checked>Fixed<br>
			       <input type = "radio" name = "fareType" value=2>Variable<br>
			<p><?php echo $error ?></p>
			<input type="radio" name="vehicleType" value=1 checked>Metro</input>
			<input type="radio" name="vehicleType" value=2>Bus</input>
			<input type ="submit" value = "Activate"/>
		</form>
	</body>
</html>

