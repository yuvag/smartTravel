<?php 
	session_start();
	include_once('fileProcessor.php');
	//include_once('dbmanager.php');
	$invalid_input = "";
	$bus_name_error = "";
	$from_error = "";	
	$to_error = "";
	$bus_name = NULL;
	$from = NULL;
	$to = NULL;
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(!empty($_POST['bus_name'])){
			$bus_name = $_POST['bus_name'];
			if(!empty($_POST['from']) and is_a_valid_bus_stop($_POST['from'])){
				$from = $_POST['from'];
				if(!empty($_POST['to']) and is_a_valid_bus_stop($_POST['to'])){
					$to = $_POST['to'];		
					$stops = route_of_bus($bus_name,$from,$to);	
					$_SESSION['bus_name'] = $bus_name;
					activate_ticketingDevice($_SESSION['username'],json_encode($stops));
					header('Location:ticketingDevicePage.php');
				}
				else
					$to_error = "Bus stop doesn't exist";					
			}
			else
				$from_error = "Bus stop doesn't exist";
		}
		else
			$bus_name_error = "Invalid bus name";
	}
?>
<html>
	<head>
		<title>SmartTravel</title>
		<link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.1/themes/base/minified/jquery-ui.min.css" type="text/css" />
	</head>
	<body>
		<?php 
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
			if($_SESSION['privilege'] != 2){
				header('HTTP/1.0 404 Not Found');
				die("<h1>404 Not Found</h1>");
			}
			$vType = vehicleType($_SESSION['username']);
			if($vType != 2){
				header('HTTP/1.0 404 Not Found');
				die("<h1>404 Not Found</h1>");
			}
		?>
		<form action = "<?php echo $_SERVER['PHP_SELF']; ?>" method = "POST">
			<input type = "text" name="bus_name" placeholder = "Bus name">
			<br>
			<?php echo $bus_name_error; ?>
			<input type = "text" name="from" placeholder = "From" class = "auto">
			<br>
			<?php echo $from_error; ?>
			<input type = "text" name="to" placeholder = "To" class = "auto">
			<br>
			<?php echo $to_error; ?>
			<input type = "submit" value = "Go">
			<?php echo $invalid_input; ?>
		</form>
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>	
		<script type="text/javascript">
			$(function() {
	
				//autocomplete
				$(".auto").autocomplete({
					source: function(request,response){
						$.getJSON("search.php",{term:request.term,vehicleType:$('input[name=vehicleType]:checked').val()},response);
			
					},
					minLength: 2
				});				
				
			});	
		</script>
	</body>
</html>
