<?php
	require('dbmanager.php');
	session_start();
	$error = "";
	if($_SERVER['REQUEST_METHOD'] == "POST"){
		if(empty($_POST['password']))
			$error = "Password can't be empty";	
		else{
			if(validate($_SESSION['username'],$_POST['password'])){
				header('Location:logout.php');
			}
			else{
				header('Location:ticketingDevicePage.php');	
			}
		}	
	}
?>
<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php 
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
			
			if($_SESSION['privilege'] != 2){
				header('HTTP/1.0 404 Not Found');
				die("<h1>404 Not Found</h1>");
			}
		?>
		<form action = "<?php echo $_SERVER['PHP_SELF'] ?>" method = "POST" >
			Password :<input type = "password" name = "password"/>
			<br>
			<p><?php echo $error ?></p>
			<input type="submit" value = "logout">
		</form>
	</body>
</html>
