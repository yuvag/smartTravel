<?php
	require('fileProcessor.php');
	session_start();
	$file_wrong_format = "";	
	if(isset($_FILES['routeFile'])){
		if(empty($_FILES['routeFile']['error'])){
			move_uploaded_file($_FILES['routeFile']['tmp_name'],"routeFiles/".$_FILES['routeFile']['name']);		
		
			$param = 0;
			if($_POST['recordType'] == 'day')
				$param = $_POST['dayType'];
			else if($_POST['recordType'] == 'week')
				$param = 7;
			if($_POST['vehicleType'] == "metro"){
				
				if(processMetroRouteFile($_FILES['routeFile']['name'],$param) == -1)
					$file_wrong_format = "some error in file";
				display_metro();
				finish_my_work();
			}			
			else if($_POST['vehicleType'] == "bus"){
				if(processBusRouteFile($_FILES['routeFile']['name'],$param) == -1)
					$file_wrong_format = "Some error in file";
				display_bus();
				finish_my_work();
			}
		}
		else{
			$file_wrong_format = "Error in uploading file";		
		}
	} 
?>
<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
			if($_SESSION['privilege'] != 1){
				header("HTTP/1.1 404 Not Found");	
				die("<h1>404 Not Found</h1>");			
			}
		?>
		<a href="adminPage.php">Home</a>
		<form action = "<?php echo $_SERVER['PHP_SELF'] ?>"  method = 'POST' enctype="multipart/form-data">
			Type of vehicle : <select name = "vehicleType">
						<option value="metro">Metro</option>
						<option value="bus" selected>Bus</option>
					  </select>
			<br>
			For a <input type="radio" name="recordType" value="day"  onclick="document.getElementById('days').style.display = 'block'">Day</input>
			      <input type="radio" name="recordType" value="week" onclick="document.getElementById('days').style.display = 'none'">Week</input>
			
			
			<br>
			<select name = "dayType" id="days">
				<option value = 0>Sunday</option>
				<option value = 1>Monday</option>
				<option value = 2>Tuesday</option>
				<option value = 3>Wednesday</option>
				<option value = 4>Thursday</option>
				<option value = 5>Friday</option>
				<option value = 6>Saturday</option>
			</select>
			<br>
			<input type = "file" name="routeFile" required accept=".csv" />
			<p><?php echo $file_wrong_format ?></p>
			<br>		
			<input type="submit" value = "submit">	
		</form>
	</body>
</html>
