<?php 
	session_start();
	include_once('fileProcessor.php');
	include_once('dbmanager.php');
	include_once('routefinder.php');
	$disabled = false;
	$srcLat = -1;
	$srcLon = -1;
	$destLat = -1;
	$destLon = -1;
	$from_error = "";
	$to_error = "";
	$routeStrings = array();
	$submitClicked = false;
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(!empty($_POST['from'])){
			if($_POST['from'] == -1){
				//Use user's current location
				$url = json_decode(file_get_contents("http://api.ipinfodb.com/v3/ip-city/?key=3763dfaea88ea52ad826529a2c3b50236ccede8f2b79ad5abfaa7036250af573&ip=".$_SERVER['REMOTE_ADDR']."&format=json"));
	 			$srcLat = $url->latitude;
				$srcLon = $url->longitude; 
			}
			else{
				$location = $_POST['from'];
				$tmp = location_to_coords($location,"");
				$srcLat = $tmp[0];
				$srcLon = $tmp[1];
			}
		}
		else
			$from_error = "Source is not valid";
		if(!empty($_POST['to'])){
			$location = $_POST['to'];
			$tmp = location_to_coords($location,"Delhi,India");
			$destLat = $tmp[0];
			$destLon = $tmp[1];
			$routes = find_route($srcLat,$srcLon,$destLat,$destLon);
			$routeStrings = makeRouteString($routes);
			$submitClicked = true;
		}	
		else
			$to_error = "Destination is not valid";	
	}
	
	function makeRouteString($routes){
		$result = array();
		for($i = 0;$i < count($routes);$i++){
			
			if(count($routes[$i]) > 0){
				$tmp = "Source > ";
				
				$fare = 0;
				for($j = 0;$j < count($routes[$i]);$j++){
					$tmp =$tmp.$routes[$i][$j]->vehicleType." ".$routes[$i][$j]->vehicle." to ".$routes[$i][$j]->dest ;
				
					$fare += $routes[$i][$j]->fare;
					if($j < count($routes[$i]) - 1)
						$tmp = $tmp.">";	
				}		
				$tmp = $tmp."<br>";
				$tmp = $tmp."Estimated time :".(string)$time."  Estimated fare* : ".(string)$fare; 
				array_push($result,$tmp);
			}
		}	
		return $result;
	}	
?>
<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php 
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
		?>
		<br>
		<a href="userPage.php">Home</a>
		<br>
		<a href = "logout.php">Logout</a>
		<br>
		<a href = "userWallet.php">My Wallet</a>
		<br>
		<a href = "tripManager.php">My trip</a>
		<br>
		<form name = "info" action = "<?php echo $_SERVER['PHP_SELF']; ?>" method = "POST">
			<input type="text" name ="from" placeholder = "from" id="from">
			
			<input type="button" id="button" onclick="disable_field();" value = "Use my location"> 
			<br>
			<?php echo $from_error; ?>
			<br>
			<input type="text" name = "to" placeholder = "to">
			<br>
			<?php echo $to_error; ?>
			<br>
			<input type="submit" value = "Find routes">
		</form>
		<script>
			function disable_field(){
				var from = document.getElementById('from');
				if(from.style.display == 'none'){
					from.style.display = 'inline';
					from.value = "";
				}	
				else{
					from.style.display = 'none';			
					from.value = "-1";
				}
			}
		</script>
		<?php
			if($submitClicked){
				if(count($routeStrings) == 0)
					echo "No route to display";
				else{
					for($i = 0;$i < count($routeStrings);$i++){
						echo $routeStrings[$i]."<br><br>";
					}			
				}
			}
		?>			
	</body>
