<?php
	session_start();
	require('fileProcessor.php');
	$from_error = "";
	$to_error = "";
	$src = "";
	$dest = "";
	$srcOK = false;
	$destOK = false;
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if($_POST['vehicleType'] == "bus"){
			if(!empty($_POST['from']) and is_a_valid_bus_stop($_POST['from'])){
				$src = $_POST['from'];
				$srcOK = true;			
			}
			else
				$from_error = "Source is not valid";
			if(!empty($_POST['to']) and is_a_valid_bus_stop($_POST['to'])){
				$dest = $_POST['to'];
				$destOK = true;
			}
			else
				$to_error = "Destination is not valid";
			if($srcOK and $destOK){				
				delete_bus_route($src,$dest);
				if($_POST['type'] == 2)
					delete_bus_route($dest,$src);
				finish_my_work();
				display_bus();
				echo "<p>Route deleted successfully!</p>";
			}
		}
		else if($_POST['vehicleType'] == "metro"){
			if(!empty($_POST['from']) and is_a_valid_metro_station($_POST['from'])){
				$src = $_POST['from'];
				$srcOK = true;	
			}
			else
				$from_error = "Source is not valid";
			if(!empty($_POST['to']) and is_a_valid_metro_station($_POST['from'])){
				$dest = $_POST['to'];
				$destOK = true;			
			}
			else
				$to_error = "Destination is not valid";
			if($srcOK and $destOK){
				delete_metro_route($src,$dest);
				if($_POST['type'] == 2)
					delete_metro_route($dest,$src);
				finish_my_work();
				display_metro();
				echo "<p> Route deleted successfully!</p>";
			}
		} 
	}
?>

<html>
	<head>
		<title>SmartTravel</title>
		<link rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.1/themes/base/minified/jquery-ui.min.css" type="text/css" />
	</head>
	<body>
		<?php 
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
			
			if($_SESSION['privilege'] == 1)
				echo "<p>Hey Admin</p>";
			else{		
				header('HTTP/1.0 404 Not Found');
				die("<h1>404 Not Found</h1>");
			}
		?>
		<a href = "adminPage.php">Home</a>
		<br>
		<form action = "<?php echo $_SERVER['PHP_SELF'] ?>" method = "POST">
			<input type="radio" name="vehicleType" value="metro">Metro</input>
			<input type="radio" name="vehicleType" value="bus" checked>Bus</input>
			<br>			
			<input type="text" placeholder="From" name="from" class="auto">
			<?php echo $from_error; ?>
			<br>
			<input type="text" placeholder="to" name="to" class="auto">
			<?php echo $to_error; ?>
			<br>
			
			<input type="radio" name="type" value="1" checked>One Way</input>
			<input type="radio" name="type" value="2">Two Way</input>
			<br>				
			
			<input type="submit" value = "Delete">		
		</form>			
		
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
		<script type="text/javascript" src="http://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>	
		<script type="text/javascript">
		$(function() {
	
			//autocomplete
			$(".auto").autocomplete({
				source: function(request,response){
					$.getJSON("search.php",{term:request.term,vehicleType:$('input[name=vehicleType]:checked').val()},response);
			
				},
				minLength: 2
			});				

		});	
		</script>
	</body>
</html>
