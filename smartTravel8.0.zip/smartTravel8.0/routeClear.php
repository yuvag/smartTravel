<?php
	session_start();
	require('fileProcessor.php');
	clear();
?>

<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
			if($_SESSION['privilege'] != 1){
				header("HTTP/1.1 404 Not Found");	
				die("<h1>404 Not Found</h1>");			
			}
		?>
		<p> All data cleared !</p>
	</body>
</html>
