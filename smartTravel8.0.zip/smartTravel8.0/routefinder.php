<?php
	$bus_routeFile = getcwd().DIRECTORY_SEPARATOR."routeFiles".DIRECTORY_SEPARATOR."bus".DIRECTORY_SEPARATOR."routes";
	$metro_routeFile = getcwd().DIRECTORY_SEPARATOR."routeFiles".DIRECTORY_SEPARATOR."metro".DIRECTORY_SEPARATOR."routes";

	include_once('dbmanager.php');
	include_once('fileProcessor.php');
	
	class path{
		var $vehicle;
		var $vehicleType;
		var $fare;
		var $time;
		var $dest;
		function __construct($vehicle,$vehicleType,$fare,$time,$dest){
			$this->vehicle = $vehicle;
			$this->vehicleType = $vehicleType;
			$this->fare = $fare;
			$this->time = $time;			
			$this->dest = $dest;
		}	
	}

	$routes = array(array());
	$tempRoutes = array(array());
	$visited_bus_stops = array();
	$visited_metro_stations = array();

	$walking_distance = 1;
	$walking_speed = 0.00083333; // Miles per second
	
	$maxExchange = 4;
	
	$bus_stop_graph=NULL;
	$metro_station_graph = NULL;
	$visited_bus_stop = array();
	$visited_metro_station = array();

	$fareIdx = 0;
	$timeIdx = 0;

	function radians($deg){
		return ($deg * 3.14)/180.0;		
	}

	function distance($srcLat,$srcLon,$destLat,$destLon){
		return 3959 * acos(cos(radians($srcLat))*cos(radians($destLat))*cos(radians($destLon) - radians($srcLon))+sin(radians($srcLat)) *sin(radians($destLat))); 	
	}

	function load_file(){
		global $bus_routeFile, $metro_routeFile, $bus_stop_graph,$metro_station_graph;
		if(file_exists($bus_routeFile)){
			$objdata = file_get_contents($bus_routeFile);
			$bus_stop_graph = unserialize($objdata);		
		}
		if(file_exists($metro_routeFile)){
			$objdata = file_get_contents($metro_routeFile);	
			$metro_station_graph = unserialize($objdata);		
		}
	}

	function findPath($src,$dest,$count,$route,$vType,$destLat,$destLon){
		global $routes,$walking_speed,$walking_distance,$fareIdx,$timeIdx;
		if($src == $dest){
			if($vType == 1){
				$tmp = coords_of_bus_stop($dest);
				$dist = distance($destLat,$destLon,$tmp[0],$tmp[1]);
				if($dist >= 0){
					$tmp = new path(NULL,"Walk",0,$dist/$walking_speed,"Destination");
					array_push($route,$tmp);
				}
				else
					return;		
			}
			else if($vType == 2){
				$tmp = coords_of_metro_station($dest);
				$dist = distance($destLat,$destLon,$tmp[0],$tmp[1]);
	
				if($dist >= 0){
					$tmp = new path(NULL,"Walk",0,$dist/$walking_speed,"Destination");
					array_push($route,$tmp);
				}
				else
					return;
			}
			
			array_push($routes,$route);
			return;	
		}	
		global $bus_stop_graph,$metro_station_graph,$walking_speed;
		if($count == 0)
			return;
		if($vType == 1){
			if(isset($bus_stop_graph[$src])){
				for($i = 0;$i < count($bus_stop_graph[$src]);$i++){
					//Can go to next bus stop by bus
					if(isset($bus_stop_graph[$src][$i])){
						
						$tmp = new path($bus_stop_graph[$src][$i]->vehicle,"Bus",$bus_stop_graph[$src][$i]->fare[$fareIdx],$bus_stop_graph[$src][$i]->time[$timeIdx],bus_stop_name($bus_stop_graph[$src][$i]->dest)." Bus stop");
						array_push($route,$tmp);
						findPath($bus_stop_graph[$src][$i]->dest,$dest,$count-1,$route,1,$destLat,$destLon);
						array_pop($route);	
										
					
						//Can go to next bus stop by walk or private vehicle
						$tmp = coords_of_bus_stop($bus_stop_graph[$src][$i]->dest);
						if($tmp == NULL)
							return;
						$bus_stop = nearest_bus_stop($tmp[0],$tmp[1]);		
						if($bus_stop == NULL)
							return;
						$bus_stop_coords = coords_of_bus_stop($bus_stop);
						if($bus_stop_coords == NULL)
							return ;
						$dist = distance($tmp[0],$tmp[1],$bus_stop_coords[0],$bus_stop_coords[1]);
					
						$tmp = new path(NULL,"Walk",0,$dist/$walking_speed,bus_stop_name($bus_stop)." Bus stop");
						array_push($route,$tmp);
						findPath($bus_stop_graph[$src][$i]->dest,$dest,$count - 1,$route,1,$destLat,$destLon);
						array_pop($route);
					
						//Can go to next metro station by walk or private vehicle
						$tmp = coords_of_bus_stop($bus_stop_graph[$src][$i]->dest);
						if($tmp == NULL)
							return ;
						$metro_station = nearest_metro_station($tmp[0],$tmp[1]);	
						if($metro_station == NULL)
							return;		
						$metro_station_coords = coords_of_metro_station($bus_stop);
						if($metro_station_coords == NULL)
							return;
						$dist = distance($tmp[0],$tmp[1],$metro_station_coords[0],$metro_station_coords[1]);
					
						$tmp = new path(NULL,"Walk",0,$dist/$walking_speed,metro_station_name($metro_station)." Metro Station");
						array_push($route,$tmp);
						findPath($bus_stop_graph[$src][$i]->dest,$dest,$count-1,$route,2,$destLat,$destLon);
						array_pop($route);
					}	
				}
			}			
		}
		else{
			if(isset($metro_station_graph[$src])){
				for($i = 0;$i < count($metro_station_graph[$src]);$i++){
					//Can go to next bus stop by bus
					if(isset($metro_station_graph[$src][$i])){
						$tmp = new path(NULL,"Metro",NULL,NULL,metro_station_name($metro_station_graph[$src][$i]->dest)." Metro Station");
						array_push($route,$tmp);
						findPath($metro_station_graph[$src][$i]->dest,$dest,$count-1,$route,2,$destLat,$destLon);
						array_pop($route);				
						
					}
					//Can go to next metro station by walk or private vehicle
					$tmp = coords_of_metro_station($metro_station_graph[$src][$i]->dest);
					if($tmp == NULL)
						return;
					$metro_station = nearest_metro_station($tmp[0],$tmp[1]);
					if($metro_station == NULL)
						return;		
					$metro_station_coords = coords_of_metro_station($metro_station);
					if($metro_station_coords == NULL)
						return;
					$dist = distance($tmp[0],$tmp[1],$metro_station_coords[0],$metro_station_coords[1]);
					
					$tmp = new path(NULL,"Walk",0,$dist/$walking_speed,metro_station_name($metro_station)." Metro Station");
					array_push($route,$tmp);
					findPath($metro_station_graph[$src][$i]->dest,$dest,$count - 1,$route,2,$destLat,$destLon);
					array_pop($route);
					
					//Can go to next metro station by walk or private vehicle
					$tmp = coords_of_metro_station($metro_station_graph[$src][$i]->dest);
					if($tmp == NULL)
						return;
					$bus_stop = nearest_bus_stop($tmp[0],$tmp[1]);		
					if($bus_stop == NULL)
						return;
					$bus_stop_coords = coords_of_bus_stop($bus_stop);
					if($bus_stop_coords == NULL)
						return;
					$dist = distance($tmp[0],$tmp[1],$bus_stop_coords[0],$bus_stop_coords[1]);
					
					$tmp = new path(NULL,"Walk",0,$dist/$walking_speed,bus_stop_name($bus_stop)." Bus stop");
					array_push($route,$tmp);
					findPath($bus_stop_graph[$src][$i]->dest,$dest,$count-1,$route,1,$destLat,$destLon);
					array_pop($route);	
					
				}
			}	
		}
	}

	function find_route($srcLat,$srcLon,$destLat,$destLon){
		global $maxExchange,$walking_speed,$routes,$walking_distance;
		load_file();
		$srcBusStop = nearest_bus_stop($srcLat,$srcLon);
		$destBusStop = nearest_bus_stop($destLat,$destLon);

		$date = new DateTime();
			
		$fareIdx = isNight($date);
		$timeIdx = $date->format('w'); 
			
		$bus_stops = no_of_bus_stops();
		$metro_stations = no_of_metro_stations();
		
		if($srcBusStop != NULL and $destBusStop != NULL){
			$tmp = coords_of_bus_stop($srcBusStop);
			if($tmp != NULL){
				$dist = distance($srcLat,$srcLon,$tmp[0],$tmp[1]);
				$route = array();
				if($dist >= 0){
					$tmp = new path(NULL,"Walk",0,$dist/$walking_speed,bus_stop_name($srcBusStop)." Bus stop");
					array_push($route,$tmp);
					findPath($srcBusStop,$destBusStop,$maxExchange,$route,1,$destLat,$destLon); //Going to bus stop initially
				}
			}
		}
		$route = array();
		$srcMetroStop = nearest_metro_station($srcLat,$srcLon);
		$destMetroStop = nearest_metro_station($destLat,$destLon);
		if($srcMetroStop != NULL and $destMetroStop != NULL){
			$tmp = coords_of_metro_station($srcMetroStop);
			if($tmp != NULL){
				$dist = distance($srcLat,$srcLon,$tmp[0],$tmp[1]);
				if($dist > 0 and $dist <= $walking_distance){
					$tmp = new path(NULL,"Walk",0,$dist/$walking_speed,metro_station_name($srcMetroStop)." Metro Station");
					array_push($route,$tmp);
					findPath($srcMetroStop,$destMetroStop,$maxExchange,$route,2,$destLat,$destLon); //Going to metro stop initially
				}
			}
		}
		return $routes;		
	}	
	
?>
