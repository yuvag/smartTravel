<?php
	require('check.php');
	require('dbmanager.php');
	$username_error = "";
	$password_error = "";
	$usernameOK = false;
	$passwordOK = false;
	$validation_error = "";
	$OK = false;
	$privilege = -1;
	$username = "";
	//Check whether it is a POST request, if it is a GET request invalidate that
	if($_SERVER['REQUEST_METHOD'] == "POST"){
		$username = "";
		$password = "";
		if(empty($_POST['username']))
			$username_error = "Username can't be empty";		
		else{
			$username = process($_POST["username"]);
			if(checkdata($username)){
				$username = $username;
				$usernameOK = true;
			}
			else
				$username_error = "Name cannot contain illegal characters";
		}
		if(empty($_POST['password']))
			$password_error = "Password can't be empty";
		else{
			$password = $_POST["password"];
			$passwordOK = true;
		}
		if($usernameOK and $passwordOK){
			//Check in database		
			if(validate($username,$password)){
				$privilege = privilege_level($username);
				$OK = true;
			}
			else{
				$validation_error = "Invalid username/password";		
			}	
		}	
	}
?>

<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php 
			if(!empty($_SESSION['username']))
				session_destroy();
		?>
		<a href="index.html">Home</a>
		<form method = "POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" >
			<p> * Required fields </p>
			*Username : <input type = "text" name = "username">
			<p><?php echo $username_error ?></p>
			<br>
			*Password : <input type = "password" name = "password">
			<p><?php echo $password_error ?></p>
			<br>
			<p><?php echo $validation_error ?></p>
			<input type = "submit" value = "login">
		</form>
		<?php 
			if($OK){
					
				session_start();
				$_SESSION["username"] = $username;
				$_SESSION["privilege"] = $privilege;
				$vType = vehicleType($username);
				
				if($privilege == 1){
					header('Location:adminPage.php');				
				}
				else if($privilege == 2){	
					if($vType == 2)
						header('Location:ticketingDeviceSettings.php');				
					else
						header('Location:ticketingDevicePage.php');
				}
				else{
					header('Location:userPage.php');				
				}
				
			}
		?>
	</body>
</html>
	
