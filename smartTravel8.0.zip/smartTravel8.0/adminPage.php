<?php
	session_start();
?>
<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		
		<?php 
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
			
			if($_SESSION['privilege'] == 1)
				echo "<p>Hey Admin</p>";
			else{		
				header('HTTP/1.0 404 Not Found');
				die("<h1>404 Not Found</h1>");
			}
		?>
		<br>	
		<a href = "adminPage.php">Home</a>
		<br>
		<a href = "routeManager.php"> Manage routes</a>
		
		<br>
		<a href = "ticketingDeviceManager.php"> Manage ticketing device</a>	
		<br>
	
		<a href = "statistics.php"> Statistics</a>		
		<br>
		<a href = "logout.php">Logout</a>
	</body>
</html>
