<?php
	include_once('dbmanager.php');
	include_once('routefinder.php');
	$bus_routeFile = getcwd().DIRECTORY_SEPARATOR."routeFiles".DIRECTORY_SEPARATOR."bus".DIRECTORY_SEPARATOR."routes";
	$bus_stopFile = getcwd().DIRECTORY_SEPARATOR."routeFiles".DIRECTORY_SEPARATOR."bus".DIRECTORY_SEPARATOR."stops";
	$sorted_bus_stopFile = getcwd().DIRECTORY_SEPARATOR."routeFiles".DIRECTORY_SEPARATOR."bus".DIRECTORY_SEPARATOR."sorted_stops";
	$bus_stop_trieFile = getcwd().DIRECTORY_SEPARATOR."routeFiles".DIRECTORY_SEPARATOR."bus".DIRECTORY_SEPARATOR."stops_trie";
	$bus_countFile = getcwd().DIRECTORY_SEPARATOR."routeFiles".DIRECTORY_SEPARATOR."bus".DIRECTORY_SEPARATOR."stops_count";

	$metro_routeFile = getcwd().DIRECTORY_SEPARATOR."routeFiles".DIRECTORY_SEPARATOR."metro".DIRECTORY_SEPARATOR."routes";
	$metro_stationFile = getcwd().DIRECTORY_SEPARATOR."routeFiles".DIRECTORY_SEPARATOR."metro".DIRECTORY_SEPARATOR."stops";
	$sorted_metro_stationFile = getcwd().DIRECTORY_SEPARATOR."routeFiles".DIRECTORY_SEPARATOR."metro".DIRECTORY_SEPARATOR."sorted_stops";
	$metro_station_trieFile = getcwd().DIRECTORY_SEPARATOR."routeFiles".DIRECTORY_SEPARATOR."metro".DIRECTORY_SEPARATOR."stops_trie";
	$metro_countFile = getcwd().DIRECTORY_SEPARATOR."routeFiles".DIRECTORY_SEPARATOR."metro".DIRECTORY_SEPARATOR."stops_count";
	
	class Time{
		var $HH,$MM,$SS;
		function __construct($HH,$MM,$SS){
			$this->HH = $HH;
			$this->MM = $MM;
			$this->SS = $SS;		
		}
	}

	$nightTime = new Time(22,30,0);
	$dayTime = new Time(5,0,0);
	
	$metro_loaded = false;
	$metro_saved = true;
	$bus_loaded = false;
	$bus_saved = true;
	
	function isNight($time){
		global $nightTime,$dayTime;
		$HH = intval($time->format('H'));
		$MM = intval($time->format('i'));
		$SS = intval($time->format('s'));		
	
		if($HH >= $nightTime->HH or $HH < $dayTime->HH)
			return true;
		
		return false;
	}
	
	class edge{
		var $dest;
		var $time; 	//time to travel between source and destination
		var $fare;
		var $vehicle;
		
		function __construct($dest,$time,$fare,$vehicle){
			$this->dest = $dest;
			$this->time = $time;
			$this->fare = $fare;	
			$this->vehicle = $vehicle;	
		}
	}

	$bus_stop_hash = array();
	$metro_station_hash = array();
	
	class node{
		var $ref = array();
		var $idx;	
		
		function __construct(){/*
			$this->ref['a'] = $this->ref['b'] = $this->ref['c'] = $this->ref['d'] = $this->ref['e'] = $this->ref['f'] = NULL;
			$this->ref['g'] = $this->ref['h'] = $this->ref['i'] = $this->ref['j'] = $this->ref['k'] = $this->ref['l'] = NULL;
			$this->ref['m'] = $this->ref['n'] = $this->ref['o'] = $this->ref['p'] = $this->ref['q'] = $this->ref['r'] = NULL;
			$this->ref['s'] = $this->ref['t'] = $this->ref['u'] = $this->ref['v'] = $this->ref['w'] = $this->ref['x'] = NULL;
			$this->ref['y'] = $this->ref['z'] = NULL;*/			
			$this->idx = -1;		
		}		
	}

	class coordinates{
		var $latitude;
		var $longitude;	
		var $idx;
		function __construct($latitude,$longitude,$idx){
			$this->latitude = $latitude;
			$this->longitude = $longitude;
			$this->idx = $idx;
		}
	}

	$bus_stop_graph = array();
	$metro_station_graph = array();
	$bus_stop_count = 0;
	$bus_stop_trie = new node();
	$metro_station_trie = new node();
	$sorted_bus_stop = array();
	$sorted_metro_station = array();
	$metro_station_count = 0;
	$map_width = 10000.0;
	$map_height = 10000.0;

	function finish_my_work(){	
		global $bus_saved,$bus_loaded;
		global $metro_saved,$bus_saved;
		if(!$bus_saved){
			$bus_loaded = false;
			$bus_saved = true;
			save_bus();
		}
		if(!$metro_saved){
			save_metro();
			$metro_loaded = false;
			$metro_saved = true;		
		}		
	}

	function load_bus(){
		global $bus_stop_graph,$bus_stop_count,$bus_stop_trie,$bus_stop_hash;
		global $bus_routeFile,$bus_stopFile,$bus_countFile,$bus_stop_trieFile;
		if(file_exists($bus_routeFile)){
			$objdata = file_get_contents($bus_routeFile);
			$bus_stop_graph = unserialize($objdata);		
		}
		if(file_exists($bus_stopFile)){
			$objdata = file_get_contents($bus_stopFile);
			$bus_stop_hash = unserialize($objdata);		
		}	
		if(file_exists($bus_countFile)){
			$objdata = file_get_contents($bus_countFile);
			$bus_stop_count = unserialize($objdata);			
		}
		if(file_exists($bus_stop_trieFile)){
			$objdata = file_get_contents($bus_stop_trieFile);
			$bus_stop_trie = unserialize($objdata);		
		}
	}

	function load_metro(){
		global $metro_station_graph,$metro_station_count,$metro_station_trie,$metro_station_hash;
		global $metro_routeFile,$metro_stationFile,$metro_countFile,$metro_station_trieFile;
		if(file_exists($metro_routeFile)){
			$objdata = file_get_contents($metro_routeFile);
			$metro_station_graph = unserialize($objdata);		
		}
		if(file_exists($metro_stationFile)){
			$objdata = file_get_contents($metro_stationFile);
			$metro_station_hash = unserialize($objdata);		
		}	
		if(file_exists($metro_countFile)){
			$objdata = file_get_contents($metro_countFile);
			$metro_station_count = unserialize($objdata);			
		}
		if(file_exists($metro_station_trieFile)){
			$objdata = file_get_contents($metro_station_trieFile);
			$metro_station_trie = unserialize($objdata);		
		}
	}


	function location_to_coords($location,$extra){
		//Common for both bus and metro
		$Address = urlencode($location.$extra);
		$request_url = "http://maps.googleapis.com/maps/api/geocode/xml?address=".$Address."&sensor=true";	
		$xml = simplexml_load_file($request_url) or die('Try contacting administrator');
		$status = $xml->status;
		$Lat = -1;
		$Lon = -1;
		if($status == "OK"){
			$Lat = $xml->result->geometry->location->lat;
			$Lon = $xml->result->geometry->location->lng;		
			return array(floatval($Lat),floatval($Lon));
		}
		else
			return location_to_coords($location,$extra);
	}
	

	function bus_stop_number($stopName){
		global $bus_loaded,$bus_saved;
		if(!$bus_loaded){
			load_bus();
			$bus_loaded = true;
		}
		$stopName = strtolower($stopName);	
		global $bus_stop_trie,$bus_stop_count;
		$N = strlen($stopName);
		$root = $bus_stop_trie;
		for($i = 0;$i < $N;$i++){
			if(!isset($root->ref[$stopName[$i]]))
				$root->ref[$stopName[$i]] = new node();
			$root = $root->ref[$stopName[$i]];					
		}
		$bus_saved = false;
		if($root->idx == -1){
			$root->idx = $bus_stop_count++;	
			return $root->idx;
		}
		return $root->idx;
	}

	function metro_station_number($stopName){
		global $metro_loaded, $metro_saved;
		if(!$metro_loaded){
			$metro_loaded = true;
			load_metro();
		}
		$stopName = strtolower($stopName);	
		global $metro_station_trie,$metro_station_count;
		$N = strlen($stopName);
		$root = $metro_station_trie;
		for($i = 0;$i < $N;$i++){
			if(!isset($root->ref[$stopName[$i]]))
				$root->ref[$stopName[$i]] = new node();
			$root = $root->ref[$stopName[$i]];					
		}
		$metro_saved = false;
		if($root->idx == -1){
			$root->idx = $metro_station_count++;	
			return $root->idx;
		}
		return $root->idx;
	}	

	function insert_bus_stop($bus_stop){
		
		insert_bus_stop_coords($bus_stop->idx,$bus_stop->latitude,$bus_stop->longitude);
	}

	function insert_metro_station($metro_station){
		insert_metro_station_coords($metro_station->idx,$metro_station->latitude,$metro_station->longitude);
	}
	
	function processBusRouteFile($file_name,$day){
		global $bus_loaded, $bus_saved;
		if(!$bus_loaded){
			load_bus();
			$bus_loaded = true;		
		}
		$row = 0;
		$file_name = "routeFiles/".$file_name;
		$src = "";
		$dest = "";
		$eta = "";
		$etd = "";
		$fare = 0;
		$vehicle = "";
		global $bus_stop_graph,$bus_stop_hash;
		if(($handle = fopen($file_name,"r")) !== FALSE){
			while(($data = fgetcsv($handle,0,",")) !== FALSE){
				if($row == 0)
					$row++;
				else{
					$vehicle = $data[0];
					if(empty($vehicle))
						return -1;
					$src = $data[1];
					if(empty($src))
						return -1;
					//Check whether date is in correct format
					if(!strtotime($data[2]))
						return -1;
					$eta = date_create($data[2]);
					$dest = $data[3];
					if(empty($dest))
						return -1;
					if(!strtotime($data[4]))
						return -1;
					$etd = date_create($data[4]);
					if($etd <= $eta)
						return -1;
					if(!is_numeric($data[6]) or !is_numeric($data[5]))
						return -1;
					$fareAmt = intval($data[6])/intval($data[5]);
					$pattern = "/(DOWN|UP)/";
					$vehicle = preg_replace($pattern,"",$vehicle);
					if($day == 7)
						for($j = 0;$j < 7;$j++)
							add_bus_route($src,$eta,$dest,$etd,$vehicle,$fareAmt,$j);
					else
						add_bus_route($src,$eta,$dest,$etd,$vehicle,$fareAmt,$day);
				}
			}				
		}	
		$bus_saved = false;
		//delete that file after processing
		if(!unlink($file_name))
			die("Couldn't delete file");
		return 0;
	}
	
	function processMetroRouteFile($file_name,$day){
		global $metro_loaded, $metro_saved;
		if(!$metro_loaded){
			load_metro();
			$metro_loaded = true;		
		}
		$row = 0;
		$file_name = "routeFiles/".$file_name;
		$src = "";
		$dest = "";
		$eta = "";
		$etd = "";
		global $metro_station_graph,$metro_station_hash;
		if(($handle = fopen($file_name,"r")) !== FALSE){
			while(($data = fgetcsv($handle,0,",")) !== FALSE){
				if($row == 0)
					$row++;
				else{
					$src = $data[0];
					if(empty($src))
						return -1;
					//Check whether date is in correct format
					if(!strtotime($data[1]))
						return -1;
					$eta = date_create($data[1]);
					$dest = $data[2];
					if(empty($dest))
						return -1;
					if(!strtotime($data[3]))
						return -1;
					$etd = date_create($data[3]);
					if($etd <= $eta)
						return -1;
					if($day == 7)
						for($j = 0;$j < 7;$j++)
							add_metro_route($src,$eta,$dest,$etd,$j);
					else
						add_metro_route($src,$eta,$dest,$etd,$day);	
					
				}			
			}		
		}
		$metro_saved = false;
		//delete that file after processing
		if(!unlink($file_name))
			die("Couldn't delete file");
		return 0;
	}	

	function display_bus(){
		//Display all data structure for bus
		//For developer only
		echo "Bus<br>";
		global $bus_loaded;
		if(!$bus_loaded){
			load_bus();
			$bus_loaded = true;
		}
		global $bus_stop_graph, $bus_stop_hash;
		echo "Stops : <br>";
		for($i = 0;$i < count($bus_stop_hash);$i++){
			echo $i." : ".$bus_stop_hash[$i]."<br>";
		}
		echo "<br>";
		echo "Graph : <br>";
		for($i = 0;$i < count($bus_stop_hash);$i++){
			echo $i." : ";
			if(isset($bus_stop_graph[$i])){
				var_dump($bus_stop_graph[$i]);
			}
			echo "<br>";
		}	
		
	}	
	
	function display_metro(){
		//Display all data structure for metro
		//For developer only
		global $metro_loaded;	
		if(!$metro_loaded){
			load_metro();
			$metro_loaded = true;		
		}
		echo "Metro<br>";
		global $metro_station_graph, $metro_station_hash;
		echo "Stops : <br>";
		for($i = 0;$i < count($metro_station_hash);$i++){
			echo $i." : ".$metro_station_hash[$i]."<br>";
		}
		echo "<br>";
		echo "Graph : <br>";
		for($i = 0;$i < count($metro_station_hash);$i++){
			echo $i." : ";
			if(isset($metro_station_graph[$i])){
				var_dump($metro_station_graph[$i]);
			}
			echo "<br>";
		}	
		
	}

	function save_bus(){
		global $bus_stop_graph,$bus_stop_trie,$bus_stop_hash,$bus_stop_count;
		global $bus_routeFile,$bus_stopFile,$bus_stop_trieFile,$bus_countFile;	
		//This function will save all objects back to files
		//routes : This file will contain the graph  	
		$objdata = serialize($bus_stop_graph);
		
		$fp = fopen($bus_routeFile,"w");
		fwrite($fp,$objdata);
		fclose($fp);
		
			
		//stops : This file will contain name of all bus and metro stops
		$objdata = serialize($bus_stop_hash);
		
		$fp = fopen($bus_stopFile,"w");
		fwrite($fp,$objdata);
		fclose($fp);		
	
		//stops_trie : This file will contain trie representation of all stops
		$objdata = serialize($bus_stop_trie);
	
		$fp = fopen($bus_stop_trieFile,"w");
		fwrite($fp,$objdata);
		fclose($fp);		
		
		
		//stops_count : This file will contain number of all stops
		$objdata = serialize($bus_stop_count);
		
		$fp = fopen($bus_countFile,"w");
		fwrite($fp,$objdata);
		fclose($fp);
	}
	
	function save_metro(){
		global $metro_station_graph,$metro_station_trie,$metro_station_hash,$metro_station_count;
		global $metro_routeFile,$metro_stationFile,$metro_station_trieFile,$metro_countFile;	
		//This function will save all objects back to files
		//routes : This file will contain the graph  	
		$objdata = serialize($metro_station_graph);
		
		$fp = fopen($metro_routeFile,"w");
		fwrite($fp,$objdata);
		fclose($fp);
		
			
		//stops : This file will contain name of all bus and metro stops
		$objdata = serialize($metro_station_hash);
		
		$fp = fopen($metro_stationFile,"w");
		fwrite($fp,$objdata);
		fclose($fp);		
		
		
		//stops_trie : This file will contain trie representation of all stops
		$objdata = serialize($metro_station_trie);
	
		$fp = fopen($metro_station_trieFile,"w");
		fwrite($fp,$objdata);
		fclose($fp);		
		
		
		//stops_count : This file will contain number of all stops
		$objdata = serialize($metro_station_count);
		
		$fp = fopen($metro_countFile,"w");
		fwrite($fp,$objdata);
		fclose($fp);				
	}	
	
	function addMetroStop($stopName){
		global $metro_loaded,$metro_saved;
		if(!$metro_loaded){
			load_metro();	
			$metro_loaded = true;
		}
		global $metro_station_hash;
		$stopNo = metro_station_number($stopName);
		if(!isset($_metro_station_hash[$stopNo])){
			$metro_station_hash[$stopNo] = $stopName;
			$tmp =location_to_coords($stopName,"Delhi,India");
			insert_metro_station(new coordinates($tmp[0],$tmp[1],$stopNo));
			$metro_saved = false;
		}		
	}
	
	function addBusStop($stopName){
		global $bus_loaded, $bus_saved;
		if(!$bus_loaded){
			load_bus();
			$bus_loaded = true;	
		}
		$stopNo = bus_stop_number($stopName);
		global $bus_stop_hash; 
		if(!isset($bus_stop_hash[$stopNo])){
			$bus_stop_hash[$stopNo] = $stopName;
			$tmp = location_to_coords($stopName,"Delhi, India");
			insert_bus_stop(new coordinates($tmp[0],$tmp[1],$stopNo));
			$bus_saved = false;
		}	
	}

	function is_a_valid_bus_stop($stopName){
		global $bus_stop_trie,$bus_loaded;
		if(!$bus_loaded){
			$bus_loaded = true;
			load_bus();		
		}		
		$stopName = strtolower($stopName);
		$N = strlen($stopName);
		$root = $bus_stop_trie;
		for($i=0;$i < $N;$i++){
			if(isset($root->ref[$stopName[$i]]))
				$root = $root->ref[$stopName[$i]];
			else
				return false;		
		}
		return true;
	}	

	function is_a_valid_metro_station($stopName){
		global $metro_station_trie;
		if(!$metro_loaded){
			load_metro();
			$metro_loaded = true;
		}
		$stopName = strtolower($stopName);
		$N = strlen($stopName);
		$root = $metro_station_trie;
		for($i=0;$i < $N;$i++){
			if(isset($root->ref[$stopName[$i]]))
				$root = $root->ref[$stopName[$i]];
			else
				return false;		
		}
		return true;
	}

	function add_metro_route($src,$eta,$dest,$etd,$day){
		global $metro_loaded, $metro_saved;
		if(!$metro_loaded){
			load_metro();
			$metro_loaded = true;		
		}
		global $metro_station_graph,$metro_station_hash;
		$time = array();
		$srcNo = metro_station_number($src);
		$destNo = metro_station_number($dest);
		$found = false;
		$t = $etd->format('U') - $eta->format('U');
		$time[$day] = $t;
		if(!isset($metro_station_graph[$srcNo]))
			$metro_station_graph[$srcNo] = array();					
		
		for($i = 0;$i < count($metro_station_graph[$srcNo]);$i++){
			if($metro_station_graph[$srcNo][$i]->dest == $destNo){
				$found = true;
				if(!isset($metro_station_graph[$srcNo][$i]->time[$day]))
					$metro_station_graph[$srcNo][$i]->time[$day] = $t;		
			}
		}		
		if(!isset($metro_station_hash[$srcNo])){
			$metro_station_hash[$srcNo] = $src;
			$tmp =location_to_coords($src,"Delhi, India"); 
			insert_metro_station(new coordinates($tmp[0],$tmp[1],$srcNo));
		}
		if(!isset($metro_station_hash[$destNo])){
			$metro_station_hash[$destNo] = $dest;
			$tmp = location_to_coords($dest,"Delhi, India");
			insert_metro_station(new coordinates($tmp[0],$tmp[1],$destNo));	
		}
		if(!$found)
			array_push($metro_station_graph[$srcNo],new edge($destNo,$time,NULL,NULL));	
		$metro_saved = false;
	}
	
	function add_bus_route($src,$eta,$dest,$etd,$vehicle,$fareAmt,$day){
		//Src is source name. Data type : String
		//eta is expected time of arrival. Data type : time
		//dest is destination name. Data type : String
		//etd is expected time of reaching stop.
		//vehicle is a string of vehicle name
		//fareAmt is a number
		//day is a number denoting day of week.
		global $bus_loaded, $bus_saved;
		if(!$bus_loaded){
			load_bus();
			$bus_loaded = true;
		}
		$fare = array();
		$time = array();
					
		global $bus_stop_graph,$bus_stop_hash; 
		
					
		if(isNight($eta))
			$fare[1] = $fareAmt;
					
		else
			$fare[0] = $fareAmt;
		$srcNo = bus_stop_number($src);
		$destNo = bus_stop_number($dest);
		$found = false;
		$t = $etd->format('U') - $eta->format('U');
						
		$time[$day] = $t; 
					
		if(!isset($bus_stop_graph[$srcNo]))
			$bus_stop_graph[$srcNo] = array();					
					
		for($i = 0;$i < count($bus_stop_graph[$srcNo]);$i++){
			if($bus_stop_graph[$srcNo][$i]->dest == $destNo and strcmp($bus_stop_graph[$srcNo][$i]->vehicle,$vehicle)==0){
				$found = true;
				if(!isset($bus_stop_graph[$srcNo][$i]->fare[1]) and isNight($eta))
					$bus_stop_graph[$srcNo][$i]->fare[1] = $fareAmt;
				if(!isset($bus_stop_graph[$srcNo][$i]->fare[0]) and !isNight($eta))
					$bus_stop_graph[$srcNo][$i]->fare[0] = $fareAmt;
				if(!isset($bus_stop_graph[$srcNo][$i]->time[$day]))
					$bus_stop_graph[$srcNo][$i]->time[$day] = $t;
			}
		}
					
		if(!isset($bus_stop_hash[$srcNo])){
			$bus_stop_hash[$srcNo] = $src;
			$tmp = location_to_coords($src,"Delhi, India"); 
			insert_bus_stop(new coordinates($tmp[0],$tmp[1],$srcNo));
		}
		if(!isset($bus_stop_hash[$destNo])){
			$bus_stop_hash[$destNo] = $dest;
			$tmp = location_to_coords($dest,"Delhi,India");
			insert_bus_stop(new coordinates($tmp[0],$tmp[1],$destNo));	
		}
		if(!$found)
			array_push($bus_stop_graph[$srcNo],new edge($destNo,$time,$fare,$vehicle));
		$bus_saved = false;
	}
	function delete_bus_route($src,$dest){
		global $bus_loaded, $bus_saved;
		if(!$bus_loaded){
			load_bus();
			$bus_loaded = true;		
		}
		global $bus_stop_graph;
		$srcNo = bus_stop_number($src);
		$destNo = bus_stop_number($dest);
		$indices = array();	
		for($i=0;$i < count($bus_stop_graph[$srcNo]);$i++)
			if($bus_stop_graph[$srcNo][$i]->dest == $destNo)
				array_push($indices,$i);
		for($i=0;$i<count($indices);$i++)		
			unset($bus_stop_graph[$srcNo][$i]);	
	}
	function delete_metro_route($src,$dest){
		global $metro_loaded, $metro_saved;
		if(!$metro_loaded){
			load_metro();
			$metro_loaded = true;		
		}
		global $metro_station_graph;
		$srcNo = bus_stop_number($src);
		$destNo = bus_stop_number($dest);
		$indices = array();	
		for($i=0;$i < count($metro_station_graph[$srcNo]);$i++)
			if($metro_station_graph[$srcNo][$i]->dest == $destNo)
				array_push($indices,$i);
		for($i=0;$i<count($indices);$i++)		
			unset($metro_station_graph[$srcNo][$i]);	
	}
	
	function clear(){
		global $bus_routeFile, $metro_routeFile, $bus_stopFile, $metro_stopFile,$bus_stop_trieFile,$metro_station_trieFile,$bus_countFile,$metro_countFile,$metro_stationFile;
		if(file_exists($bus_routeFile))
			unlink($bus_routeFile);
		if(file_exists($metro_routeFile))
			unlink($metro_routeFile);
		if(file_exists($bus_stopFile))	
			unlink($bus_stopFile);
		if(file_exists($metro_stationFile))
			unlink($metro_stationFile);

		if(file_exists($bus_stop_trieFile))
			unlink($bus_stop_trieFile);
		if(file_exists($metro_station_trieFile))
			unlink($metro_station_trieFile);
		if(file_exists($bus_countFile))
			unlink($bus_countFile);
		if(file_exists($metro_countFile))
			unlink($metro_countFile);	
	}
	
	function bus_stop_name($idx){
		global $bus_stop_hash,$bus_loaded;
		if($idx == NULL)
			return NULL;
		if(!$bus_loaded){
			$bus_loaded = true;
			load_bus();
		}
		return $bus_stop_hash[$idx];		
	}	

	function metro_station_name($idx){
		if($idx == NULL)
			return NULL;
		global $metro_station_hash,$metro_loaded;
		if(!$metro_loaded){
			$metro_loaded = true;
			load_metro();		
		}
		return $metro_station_hash[$idx];	
	}
	
	$result = NULL;
	$visited_bus_stops = NULL;

	function route_of_bus($bus_name,$from,$to){
		global $bus_loaded;
		if(!$bus_loaded){
			$bus_loaded = true;
			load_bus();		
		}
		global $result,$visited_bus_stops;
		$result = array();
		$visited_bus_stops = array();
		$N = no_of_bus_stops();
		for($i = 0;$i < $N;$i++)
			$visited_bus_stops[$i] = false;	
		$srcNo = bus_stop_number($from);
		$destNo = bus_stop_number($to);
		array_push($result,$srcNo);
		find_correct_path($bus_name,$srcNo,$destNo);
		return $result;		
	}

	function find_correct_path($bus_name,$src,$dest){
		global $result,$visited_bus_stops,$bus_stop_graph;
		if($src == $dest)
			return true;
		$visited_bus_stops[$src] = true;
		for($i = 0;$i < count($bus_stop_graph[$src]);$i++){
			if(strcmp($bus_stop_graph[$src][$i]->vehicle,$bus_name) == 0){
				if(!$visited_bus_stops[$bus_stop_graph[$src][$i]->dest]){
					array_push($result,$bus_stop_graph[$src][$i]->dest);
					if(find_correct_path($bus_name,$bus_stop_graph[$src][$i]->dest,$dest))
						return true;
					array_pop($result);						
				}	
			}		
		}
		$visited_bus_stops[$src] = false;
		return false;			
	}
	
	function fare_from($from,$to,$bus_name){
		global $bus_loaded,$bus_stop_graph;
		if(!$bus_loaded){
			$bus_loaded = true;
			load_bus();		
		}
		$srcNo = bus_stop_number($from);	
		$destNo = bus_stop_number($to);
		$fare = 0;
		if(isset($bus_stop_graph[$srcNo]))
			for($i = 0;$i < count($bus_stop_graph[$srcNo]);$i++)
				if(isset($bus_stop_graph[$srcNo][$i]))
					if($bus_stop_graph[$srcNo][$i]->dest == $destNo and strcmp($bus_stop_graph[$srcNo][$i]->vehicle,$bus_name) == 0)
						return 	$bus_stop_graph[$srcNo][$i]->fare;
		return $fare;
	}
		
	function diff($x,$y){
		if($x > $y)
			return $x - $y;
		return $y - $x;		
	}

	function find_nearby_bus_stops($ticketingDevice,$Lat,$Lon){
		$stops = find_route_of_bus($ticketingDevice);
		$N = count($stops);
		$result = array();
		$diff = 100000;
		for($i = 0;$i < $N - 1;$i++){
			$tmp1 = coords_of_bus_stop($stops[$i]);
			$tmp2 = coords_of_bus_stop($stops[$i+1]);
			$dist1 = distance($tmp1[0],$tmp1[1],$Lat,$Lon);
			$dist2 = distance($tmp2[0],$tmp2[1],$Lat,$Lon);
			$dist3 = distance($tmp1[0],$tmp1[1],$tmp2[0],$tmp2[1]);
			if(diff($dist1 + $dist2,$dist3)<$diff){	
				$result[0] = $i;
				$result[1] = $i+1;
				$diff = diff($dist1 + $dist2,$dist3);
			}			
		}
		return $result;
	}
?>

