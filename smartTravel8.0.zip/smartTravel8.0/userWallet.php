<?php 
	session_start();
	require('dbmanager.php');
	$amt = amount_of_user($_SESSION['username']);
?>
<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php 
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
		?>
		<br>
		<a href="userPage.php">Home</a>
		<br>
		<a href = "logout.php">Logout</a>
		<br>
		<?php echo "Total Amount : $amt" ?>
		<a href = "recharge.php"> Recharge</a> 
	</body>
</html>
		
