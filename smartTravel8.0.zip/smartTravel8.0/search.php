<?php
	$searchTerm = strtolower($_GET['term']);
	$vehicleType = $_GET['vehicleType'];
	
	$bus_stop_trieFile = getcwd().DIRECTORY_SEPARATOR."routeFiles".DIRECTORY_SEPARATOR."bus".DIRECTORY_SEPARATOR."stops_trie";
	$metro_station_trieFile = getcwd().DIRECTORY_SEPARATOR."routeFiles".DIRECTORY_SEPARATOR."metro".DIRECTORY_SEPARATOR."stops_trie";
	$bus_stopFile = getcwd().DIRECTORY_SEPARATOR."routeFiles".DIRECTORY_SEPARATOR."bus".DIRECTORY_SEPARATOR."stops";
	$metro_stationFile = getcwd().DIRECTORY_SEPARATOR."routeFiles".DIRECTORY_SEPARATOR."metro".DIRECTORY_SEPARATOR."stops";
	
	$bus_stop_trie = array();
	$metro_station_trie = array();
	$indices = array();

	class node{
		var $ref = array();
		var $idx;	
		
		function __construct(){/*
			$this->ref['a'] = $this->ref['b'] = $this->ref['c'] = $this->ref['d'] = $this->ref['e'] = $this->ref['f'] = NULL;
			$this->ref['g'] = $this->ref['h'] = $this->ref['i'] = $this->ref['j'] = $this->ref['k'] = $this->ref['l'] = NULL;
			$this->ref['m'] = $this->ref['n'] = $this->ref['o'] = $this->ref['p'] = $this->ref['q'] = $this->ref['r'] = NULL;
			$this->ref['s'] = $this->ref['t'] = $this->ref['u'] = $this->ref['v'] = $this->ref['w'] = $this->ref['x'] = NULL;
			$this->ref['y'] = $this->ref['z'] = NULL;*/			
			$this->idx = -1;		
		}		
	}

	function list_all_suggestions($root){
		global $indices;
		if($root->idx != -1){
			array_push($indices,$root->idx);
		}
		foreach($root->ref as $tmp)
			list_all_suggestions($tmp);
	}

	
	if($vehicleType == "bus"){
		if(file_exists($bus_stop_trieFile)){
			$objdata = file_get_contents($bus_stop_trieFile);
			$bus_stop_trie = unserialize($objdata);
		}
	
		//var_dump($bus_stop_trie);
		
		$bus_stops = array();
		if(file_exists($bus_stopFile)){
			$objdata = file_get_contents($bus_stopFile);
			$bus_stops = unserialize($objdata);		
		}
		
		$result = array();
		$root = $bus_stop_trie;
		$N = strlen($searchTerm);
		for($i = 0;$i < $N;$i++){
			if(isset($root->ref[$searchTerm[$i]]))
				$root = $root->ref[$searchTerm[$i]];		
		}
		list_all_suggestions($root);
		//var_dump($root);
		for($i = 0;$i < count($indices);$i++)
			array_push($result,$bus_stops[$indices[$i]]);
		echo json_encode($result);
	}
	
	else if($vehicleType == "metro"){
		if(file_exists($metro_station_trieFile)){
			$objdata = file_get_contents($metro_station_trieFile);
			$metro_station_trie = unserialize($objdata);
		}
	
		//var_dump($bus_stop_trie);
		
		$metro_stations = array();
		if(file_exists($metro_stationFile)){
			$objdata = file_get_contents($metro_stationFile);
			$metro_stations = unserialize($objdata);		
		}
		
		$result = array();
		$root = $metro_station_trie;
		$N = strlen($searchTerm);
		for($i = 0;$i < $N;$i++){
			if(isset($root->ref[$searchTerm[$i]]))
				$root = $root->ref[$searchTerm[$i]];		
		}
		list_all_suggestions($root);
		//var_dump($root);
		for($i = 0;$i < count($indices);$i++)
			array_push($result,$metro_stations[$indices[$i]]);
		echo json_encode($result);
	}
?>
