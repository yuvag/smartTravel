<?php
	session_start();
	$error = "";
	$stopName = "";
	require('fileProcessor.php');
	require('check.php');
	if($_SERVER['REQUEST_METHOD'] == 'POST'){	
		//Check whether stop name is not empty
		if(empty($_POST['stop']))
			$error = "Stop Name can't be empty";
		else{
			//Check whether stop name contains valid character		
			$stopName = process($_POST['stop']);
			if(check_stopName($stopName)){
				if($_POST['vehicleType'] == "metro"){
					addMetroStop($stopName);
					finish_my_work();
					echo "<p>Stop created successfully</p>";
				}
				else if($_POST['vehicleType'] == "bus"){
					addBusStop($stopName);	
					finish_my_work();
					echo "<p>Stop created successfully</p>";
				}
			}
			else
				$error = "Stop Name can't contain illegal character";
		}			
	}
?>
<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
			if($_SESSION['privilege'] != 1){
				header("HTTP/1.1 404 Not Found");	
				die("<h1>404 Not Found</h1>");			
			}
		?>
		<a href='adminPage.php'>Home</a>
		<form action = "<?php echo $_SERVER['PHP_SELF']; ?>" method = "POST">
			<input type="radio" name="vehicleType" value="metro" checked>Metro</input>
			<input type="radio" name="vehicleType" value="bus"> Bus</input>
			<br>
			<input type="text" placeholder = "Enter stop name" name="stop">
			<br>
			<?php echo "<p>$error</p>"; ?>
			<input type="submit" value = "Add">
		</form>
	</body>
</html>
