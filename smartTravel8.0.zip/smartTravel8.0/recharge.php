<?php
	session_start();
?>
<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php 
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
		?>
		<br>
		<a href="userPage.php">Home</a>
		<br>
		<form action = "<?php echo $_SERVER['PHP_SELF']; ?>" method = "POST">
			<input type = "text" name = "amount" placeholder = "Amount">
			<input type = "submit" value = "Recharge">					
		</form>
	</body>
</html>
