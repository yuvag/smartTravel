<?php
	session_start();
	require('dbmanager.php');	
	require('check.php');
	$username_error = "";
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(!empty($_POST['username'])){
			$username = process($_POST['username']);
			if(checkdata($username)){
				demote($username);
				echo "<p> Account deactivated</p>";
			}
			else
				$username_error = "Username shouldn't contain illegal characters";	
		}
		else
			$username_error = "Username can't be empty";			
	}
?>

<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php 
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
			
			if($_SESSION['privilege'] != 1){		
				header('HTTP/1.0 404 Not Found');
				die("<h1>404 Not Found</h1>");
			}
		?>
		<a href="adminPage.php"> Home</a>
		<form action = "<?php echo $_SERVER['PHP_SELF']; ?>" method = "POST">
			<input type="text" name="username" placeholder ="username">
			<br>
			<?php echo $username_error; ?>
			<input type="submit" value="Deactivate">
		</form>		
	</body>
</html>
