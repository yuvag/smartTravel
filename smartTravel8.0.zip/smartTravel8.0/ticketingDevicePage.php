<?php
	session_start();
	include_once('codeGenerator.php');
	include_once('dbmanager.php');
	$pagetype = 0;
	$code_error = "";
	$fare_error = "";
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		$vType = vehicleType($_SESSION['username']);
		$pageType = fare_type($_SESSION['username']);
		if(is_numeric($_POST['code']) and strlen($_POST['code']) == $digits){
			$code = $_POST['code'];	
			if(is_a_valid_code($code)){			
				if($pageType == 1){
					if($vType == 1){
						//For metro
						
					}
					else{
						//For bus
						$url = json_decode(file_get_contents("http://api.ipinfodb.com/v3/ip-city/?key=3763dfaea88ea52ad826529a2c3b50236ccede8f2b79ad5abfaa7036250af573&ip=".$_SERVER['REMOTE_ADDR']."&format=json"));
	 					$srcLat = $url->latitude;
						$srcLon = $url->longitude;
						$bus_stops = find_nearby_bus_stops($_SESSION['username'],$srcLat,$srcLon);
						if(is_user_starting_trip($code)){
								start_user_journey($code,$bus_stops[0]);
						}
						else if(is_user_ending_trip($code)){	
							end_user_journey($code,$bus_stops[1]);
							$fare = calculate_fare($code,$_SESSION['bus_name']);
							deduct_amount_using_code($code,$fare);
						}
					}
				}
				else{
					if(is_numeric($_POST['fare'])){
						//For private vehicles
					}
					else
						$fare_error = "Fare not valid";
				}	
			}
			else
				$code_error = "Invalid code";
		}
		else
			$code_error = "Invalid code";		
	}
?>
<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php 
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
			if($_SESSION['privilege'] != 2){
				header('HTTP/1.0 404 Not Found');
				die("<h1>404 Not Found</h1>");
			}
		?>
		<?php 
			include_once('dbmanager.php');
			$pagetype = fare_type($_SESSION['username']) 
		?>
		<a href = "ticketingDevicePage.php">Home</a>
		<br>
		<a href = "ticketingDeviceLogout.php">Logout</a>
		<br>
		
		<form action = "<?php echo $_SERVER['PHP_SELF'] ?>" method = "POST">
			<input type = "text" name = "code"/>
			<br>
			<?php echo $code_error; ?>
			<?php 
				if($pagetype == 2)
					echo "<input type = 'text' name = 'fare'>";
				else if($pagetype == -1)
					die("404 Not Found");
			?>
			<?php echo $fare_error; ?>
			<input type="submit" value = "Go">
		</form>		
	</body>
</html>
