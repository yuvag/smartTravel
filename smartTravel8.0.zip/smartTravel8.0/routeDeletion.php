<?php
	session_start();
?>

<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php 
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
			
			if($_SESSION['privilege'] == 1)
				echo "<p>Hey Admin</p>";
			else{		
				header('HTTP/1.0 404 Not Found');
				die("<h1>404 Not Found</h1>");
			}
		?>
		<a href="adminPage.php">Home</a>
		<br>
		<a href="manualroutedeletion.php">Delete manually</a>
		<br>
		<a href="routeClear.php">Delete all routes</a>
		<br>
	</body>
</html>
