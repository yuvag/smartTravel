<?php
	session_start();
	require('codeGenerator.php');
	require('dbmanager.php');
	$trip_started = is_user_assigned_code($_SESSION['username']);
	if($_SERVER['REQUEST_METHOD'] == "POST"){
		if($_POST['action'] == "start"){
			$code = generate_code();
			finish_my_code_work();
			assign_user_code($_SESSION['username'],$code);
			header('Location:tripManager.php');			
		}
		else if($_POST['action'] == "end"){
			$code = code_of_user($_SESSION['username']);
			destroy_code($code);
			finish_my_code_work();
			delete_code_of_user($_SESSION['username']);		
			header('Location:tripManager.php');
		}
	}
?>
<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php 
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
		?>
		<br>
		<a href="userPage.php">Home</a>
		<br>
		<a href = "logout.php">Logout</a>
		<br>
		<?php 
		if(!$trip_started){
			print <<< END
			<form action = "tripManager.php" method = "POST">
				<input type="hidden" name="action" value = "start">
				<input type="submit" value = "Start my trip">
			</form>
END;
		}
		else{
			$code = code_of_user($_SESSION['username']);
			echo $code;
			print <<< END
			<form action = "tripManager.php" method = "POST">
				<input type="hidden" name="action" value = "end">
				<input type = "submit" value = "End my trip">
			</form>
END;
		}
		?>
	</body>
</html>
