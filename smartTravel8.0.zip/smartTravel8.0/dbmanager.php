<?php
	$dbhost = 'localhost:3306';
	$user = 'admin';
	$password = 'Smarttravel';
	$dbname = 'smartTravel';
	include_once('fileProcessor.php');
	$conn = mysqli_connect($dbhost,$user,$password,$dbname);
	if(mysqli_connect_errno()){
		die('Could not connect to database');	
	}
	function validate($username,$password){
		//This function will validate a user 
		$query = "select password_hash
			from Users
			where username = '".$username."';";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result) > 0){
			while($row = mysqli_fetch_assoc($result)){
				if(password_verify($password,$row['password_hash']))
					return true;			
			}	
		}
		return false;	
	}
	
	function register($username,$password){
		//This function will make entry into the database if username is unique
		//This function will set privilege always to 3
		//First check whether username is unique
		$query = "select count(*)
			  from Users
			  where username = '".$username."';";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result) > 0){
			while($row = mysqli_fetch_assoc($result))
				if($row['count(*)'] > 0)
					return -1;
		}

		$privilege = 3;
		//Generating password hash
		$passwdhash = password_hash($password,PASSWORD_DEFAULT);
		
		$query = "insert into Users(username,password_hash,privilege_level)
			  values('".$username."','".$passwdhash."',".$privilege.");";
		$status = mysqli_query($GLOBALS['conn'],$query);
		if(!$status)
			return 0;
		return 1;	  	
	}
	
	
	function privilege_level($username){
		//This function will return privilege level of username
		$query = "select privilege_level
			  from Users
			  where username = '".$username."';";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result) > 0){
			while($row = mysqli_fetch_assoc($result)){
				return $row['privilege_level'];			
			}		
		}
		else
			return -1;	
	}
	
	function is_a_valid_user($username){
		//This function will tell whether user identified by username is legal or not
		$query = "select count(*)
			  from Users
			  where username = '".$username."';";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result) > 0){
			while($row = mysqli_fetch_assoc($result)){
				if($row['count(*)'] > 0)
					return true;
			}		
		}
		return false;	
	}
	
	function promote($username,$new_privilege,$fareType,$vehicleType){
		$query = "update Users
			  set privilege_level = ".$new_privilege.",fareType = ".$fareType.",vehicleType = ".$vehicleType."
			  where username = '".$username."';";
		$result = mysqli_query($GLOBALS['conn'],$query);
		return $result;	
	}
	
	function fare_type($username){
		$query = "select fareType
			  from Users
			  where username = '".$username."';";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result) > 0){
			while($row = mysqli_fetch_assoc($result))
				return $row['fareType']; 		
		}		
		return -1;	
	}
	
	function amount_of_user($username){
		$query = "select amount
			  from Users
			  where username = '".$username."';";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result) > 0){
			while($row = mysqli_fetch_assoc($result))
				return $row['amount'];
		}	
	}
	
	function deduct_amount($username,$amount){
		$query = "update Users
			  set amount = amount - ".$amount."
			  where username = '".$username."';";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if($result)
			return true;
		return false;
	}
	function demote($username){
		$query = "select privilege_level
			  from Users
			  where username = '".$username."';";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result) > 0){
			while($row = mysqli_fetch_assoc($result))
				if($row['privilege_level'] != 2)
					return;			
		}
		$query	= "update Users
			   set privilege_level = 3
			   where username = '".$username."';";
		$status = mysqli_query($GLOBALS['conn'],$query);				
	}
	function no_of_users(){
		$query = "select count(*)	
			  from Users
			  where privilege_level = 3";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result) > 0){
			while($row = mysqli_fetch_assoc($result))
				return $row['count(*)'];		
		}	
		return 0;
	}	
	function no_of_ticketing_device(){
		$query = "select count(*)
			  from Users
			  where privilege_level = 2";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result) > 0){
			while($row = mysqli_fetch_assoc($result))
				return $row['count(*)'];
		}	
		return 0;
	}	
	function is_user_assigned_code($username){
		$query = "select count(*)
			  from tickets
			  where username = '".$username."';";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result) > 0){
			while($row = mysqli_fetch_assoc($result))
				return $row['count(*)'] > 0;		
		}
		return false;
	}

	function assign_user_code($username,$code){
		$query = "insert into tickets(username,code)
			  values('".$username."','".$code."');";
		$result = mysqli_query($GLOBALS['conn'], $query);
		
	}
	
	function code_of_user($username){
		$query = "select code
			  from tickets
			  where username = '".$username."';";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result) > 0){
			while($row = mysqli_fetch_assoc($result))
				return $row['code'];					
		}
	}
	
	function delete_code_of_user($username){
		$query = "delete from tickets
			  where username = '".$username."';";
		$result = mysqli_query($GLOBALS['conn'],$query);		
	}

	function insert_bus_stop_coords($idx,$lat,$lon){
		$query = "insert into busStops
			  values(".$lat.",".$lon.",".$idx.");";
		$result = mysqli_query($GLOBALS['conn'],$query);
	}
	
	function insert_metro_station_coords($idx,$lat,$lon){
		$query = "insert into metroStops
			  values(".$lat.",".$lon.",".$idx.");";
		$result = mysqli_query($GLOBALS['conn'],$query);
	}

	function nearest_bus_stop($Lat, $Lon){
		//This function will find nearest bus stop to given location
		$query = "select idx, (3959 *
				       acos(cos(radians(".$Lat."))*
					cos(radians(Latitude))*
					cos(radians(Longitude) - 
					radians(".$Lon."))+
					sin(radians(".$Lat.")) *
					sin(radians(Latitude)))
			) AS distance
			From busStops
			having distance < 5
			Order by distance Limit 0,2;"; 
		$result = mysqli_query($GLOBALS['conn'],$query);
	
		if(mysqli_num_rows($result) > 0){
			while($row = mysqli_fetch_assoc($result))
				return $row['idx'];
		}	
		return NULL;		
	}
	function nearest_metro_station($Lat, $Lon){
		//This function will find nearest bus stop to given location
		$query = "select idx, (3959 *
				       acos(cos(radians(".$Lat."))*
					cos(radians(Latitude))*
					cos(radians(Longitude) - 
					radians(".$Lon."))+
					sin(radians(".$Lat.")) *
					sin(radians(Latitude)))
			) AS distance
			From metroStops
			having distance < 1
			Order by distance Limit 0,2;"; 
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result) > 0){
			while($row = mysqli_fetch_assoc($result))
				return $row['idx'];	
		}	
		return NULL;
	}		

	function coords_of_bus_stop($idx){
		if($idx == NULL)
			return NULL;
		$query = "select Latitude, Longitude
			  from busStops
			  where idx = ".$idx.";";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result)>0)
			while($row = mysqli_fetch_assoc($result))
				return array($row[
'Latitude'],$row['Longitude']);		
		return NULL;
	}
	function coords_of_metro_station($idx){
		if($idx == NULL)
			return NULL;
		$query = "select Latitude, Longitude
			  from metroStops
			  where idx = '".$idx."';";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result))
			while($row = mysqli_fetch_assoc($result))
				return array($row['Latitude'],$row['Longitude']);		
		return NULL;
	}
	
	function no_of_bus_stops(){
		$query = "select count(*)
			  from busStops";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result))	
			while($row = mysqli_fetch_assoc($result))
				return $row['count(*)'];
	}
	
	function no_of_metro_stations(){
		$query = "select count(*)
			  from metroStops";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result))
			while($row = mysqli_fetch_assoc($result))
				return $row['count(*)'];	
	}

	function vehicleType($username){
		$query = "select VehicleType
			  from Users
			  where username = '".$username."';";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result))
			while($row = mysqli_fetch_assoc($result))
				return $row['VehicleType'];
		return -1;		
	}
	
	function activate_ticketingDevice($username,$stops){
		
		$query = "insert into busRoute
			  values('".$username."','".$stops."');";
		$result = mysqli_query($GLOBALS['conn'],$query);
	
	}

	function is_user_starting_trip($code){
		$query = "select count(*)
			  from tickets
			  where code = '".$code."' and src is NULL;";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result) > 0)
			while($row = mysqli_fetch_assoc($result))
				if($row['count(*)'] > 0)
					return true;
		return false;		
	}

	function is_a_valid_code($code){
		$query = "select count(*)
			  from tickets
			  where code = '".$code."';";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result) > 0)
			while($row = mysqli_fetch_assoc($result))
				if($row['count(*)'] > 0)
					return true;
		return false;				
	}

	function start_user_journey($code,$src){
		$query = "update tickets
			  set src = '".$src."' where code = '".$code."';";
		$result = mysqli_query($GLOBALS['conn'],$query);		
	}
	
	function is_user_ending_trip($code){
		$query = "select count(*)
			  from tickets
			  where code = '".$code."' and src is not NULL and dest is NULL;";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result) > 0)
			while($row = mysqli_fetch_assoc($result))
				if($row['count(*)'] > 0)
					return true;
		return false;	
	}	
	
	function calculate_fare($code,$bus_name){
		$src = "";
		$dest = "";
		$query = "select src,dest
			  from tickets
			  where code = '".$code."';";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result) > 0)
			while($row = mysqli_fetch_assoc($result)){
				$src = $row['src'];
				$dest = $row['dest'];
			}
		return fare_from($src,$dest,$bus_name);						
	}
	
	function end_user_journey($code,$dest){
		$query = "update tickets
			  set dest = '".$dest."'
			  where code = '".$code."';";
		$result = mysqli_query($GLOBALS['conn'],$query);		
	}
	
	function deduct_amount_using_code($code,$fare){
		$query = "update Users
			  set amount = amount - '".$fare."'
			  where username = (select username
					    from tickets
					    where code = '".$code."');";
		$result = mysqli_query($GLOBALS['conn'],$query);
		$query = "delete from tickets
			  where code = '".$code."';";
		$result = mysqli_query($GLOBALS['conn'],$query);			
	}

	function find_route_of_bus($username){
		$query = "select stops
			  from busRoute
			  where username = '".$username."';";
		$result = mysqli_query($GLOBALS['conn'],$query);
		if(mysqli_num_rows($result) > 0)
			while($row = mysqli_fetch_assoc($result))
				return json_decode($row['stops']);
		return array();		
	}	
?>
