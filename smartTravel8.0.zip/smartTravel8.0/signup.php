<?php
	require('check.php');
	require('dbmanager.php');
	$username_error = "";
	$password_error = "";
	$usernameOK = false;
	$passwordOK = false;
	$register_error = '';
	$OK = false;
	//Check whether it is a POST request, if it is a GET request invalidate that
	if($_SERVER['REQUEST_METHOD'] == "POST"){
		$username = "";
		$password = "";
		if(empty($_POST['username']))
			$username_error = "Username can't be empty";		
		else{
			$username = process($_POST["username"]);
			if(checkdata($username)){
				$username = $username;
				$usernameOK = true;
			}
			else
				$username_error = "Name cannot contain illegal characters";
		}
		if(empty($_POST['password']))
			$password_error = "Password can't be empty";
		else{
			$password = $_POST["password"];
			$passwordOK = true;
		}
		if($usernameOK and $passwordOK){
			//Put in database
			$status = register($username,$password);
			if($status == -1){
				$register_error = "Username exist";
			}	
			else if($status == 0){
				$register_error = "We are having some problem.Try contacting administrator";			
			}
			else if($status == 1){
				$OK = true;		
			}
		}	
	}
	
?>

<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<form method = "POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" >
			<p> * Required fields </p>
			*Username : <input type = "text" name = "username">
			<p><?php echo $username_error ?></p>
			<br>
			*Password : <input type = "password" name = "password">
			<p><?php echo $password_error ?></p>
			<br>
			<p><?php echo $register_error ?></p>
			<input type = "submit" value = "signup">
		</form>
		<?php 
			if($OK)
				header('Location:registrationSuccessful.html');
		?>
	</body>
</html>
	
