<?php
	session_start();
	require('dbmanager.php');
	$amt_error = "";
	$amount = 0;
	$username = "";
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		//Check whether amount is valid
		if(is_numeric($_POST['amountPaid'])){
			$amountPaid = intval($_POST['amountPaid']);
			$username = $_SESSION['accountID'];
			$amount = amount_of_user($username);
			if($amount >= $amountPaid){
				deduct_amount($username,$amountPaid);				
			}
			else
				$amt_error = "Insufficient balance";			
		}
		else
			$amt_error = "Amount is not valid";							
	}	
?>

<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php 
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
			
			if($_SESSION['privilege'] != 1){
				header('HTTP/1.0 404 Not Found');
				die("<h1>404 Not Found</h1>");
			}
		?>
		<a href = 'adminPage.php'>Home</a>
		<?php
			$username = $_SESSION['accountID'];
			echo "<h1> $username </h1>"; 
			$amount = amount_of_user($username);			
			echo "<h2> Amount remaining : $amount </h2>"; 
		?>
		<form action = "<?php echo $_SERVER['PHP_SELF']; ?>" method = "POST">
			<input type = "text" placeholder = "amountPaid" name="amountPaid">
			<br>
			<?php echo $amt_error; ?>
			<br>
			<input type = "submit" value = "Pay">		
		</form>
	</body>
</html>
