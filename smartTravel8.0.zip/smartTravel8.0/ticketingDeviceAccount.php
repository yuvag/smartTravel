<?php
	session_start();
	$username_error = "";
	require('dbmanager.php');
	require('check.php');
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		if(!empty($_POST['username'])){
			$username = process($_POST['username']);
			if(checkdata($username)){
				if(is_a_valid_user($username)){
					//Pass it to second page
					$_SESSION['accountID'] = $username;
					header('Location:userAccount.php');
				}
				else
					$username_error = "Username doesn't exist";	
			}	
			else
				$username_error = "Username can't contain illegal characters";
		}
		else
			$username_error = "Username can't be empty";	
	}		
?>

<html>
	<head>
		<title>SmartTravel</title>
	</head>
	<body>
		<?php 
			if(empty($_SESSION['username'])){
				header("HTTP/1.1 404 Not Found");
				die("<h1>404 Not Found</h1>");
			}
			
			if($_SESSION['privilege'] != 1){
				header('HTTP/1.0 404 Not Found');
				die("<h1>404 Not Found</h1>");
			}
		?>
		<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method = "POST">
			<input type="text" placeholder="Username" name="username">
			<?php echo $username_error; ?>
			<br>
			<input type="submit" value="Go">
		</form>		
	</body>
</html>
